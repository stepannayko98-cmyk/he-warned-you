package com.brpatapim.nightwhisper;

import com.brpatapim.nightwhisper.entity.ModEntities;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(NightWhisper.MODID)
public class NightWhisper {
    public static final String MODID = "nightwhisper";
    public static final Logger LOGGER = LogUtils.getLogger();

    public NightWhisper() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(modBus);
        modBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(new NightEvents());
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.WHISPER.get(), WhisperEntity.createAttributes().build());
    }
}
