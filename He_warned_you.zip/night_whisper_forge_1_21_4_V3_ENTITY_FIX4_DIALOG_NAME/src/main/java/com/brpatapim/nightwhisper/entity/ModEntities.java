package com.brpatapim.nightwhisper.entity;

import com.brpatapim.nightwhisper.NightWhisper;
import com.brpatapim.nightwhisper.WhisperEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, NightWhisper.MODID);

    public static final RegistryObject<EntityType<WhisperEntity>> WHISPER = ENTITY_TYPES.register("whisper", () ->
            EntityType.Builder.of(WhisperEntity::new, MobCategory.MONSTER)
                    .sized(0.62F, 3.05F)
                    .clientTrackingRange(96)
                    .updateInterval(1)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(NightWhisper.MODID, "whisper")))
    );
}
