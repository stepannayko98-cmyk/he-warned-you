package com.brpatapim.nightwhisper.client;

import com.brpatapim.nightwhisper.NightWhisper;
import com.brpatapim.nightwhisper.WhisperEntity;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.resources.ResourceLocation;

public class WhisperRenderer extends EntityRenderer<WhisperEntity, EntityRenderState> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(NightWhisper.MODID, "textures/entity/whisper.png");

    public WhisperRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.65F;
    }

    @Override
    public EntityRenderState createRenderState() {
        return new EntityRenderState();
    }

    public ResourceLocation getTextureLocation(EntityRenderState state) {
        return TEXTURE;
    }
}
