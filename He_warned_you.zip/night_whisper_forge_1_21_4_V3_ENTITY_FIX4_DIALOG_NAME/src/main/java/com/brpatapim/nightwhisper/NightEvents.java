package com.brpatapim.nightwhisper;

import com.brpatapim.nightwhisper.entity.ModEntities;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class NightEvents {
    private static final Random RANDOM = new Random();
    private final Map<UUID, HorrorState> states = new HashMap<>();

    private static class HorrorState {
        int nextAmbient = 600 + RANDOM.nextInt(2600);
        int nextWarning = 900 + RANDOM.nextInt(3200);
        int warningTicks = 0;
        int revealTicks = 0;
        int chaseTicks = 0;
        int chasePulse = 0;
        int pendingAnswerTicks = 0;
        int nextForcedChase = -1;
        int storyIndex = -1;
        int storyDelay = 0;
        int loginKickTicks = -1;
        float warningYaw = 0.0F;
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        HorrorState state = states.computeIfAbsent(player.getUUID(), id -> new HorrorState());
        if (state.loginKickTicks > 0) {
            state.loginKickTicks--;
            if (state.loginKickTicks == 0 && isCaughtForever(player)) {
                kickWarned(player);
                return;
            }
        }
        tickAmbient(player, state);

        if (state.revealTicks > 0) {
            tickReveal(player, state);
            return;
        }

        if (state.chaseTicks > 0) {
            tickChase(player, state);
            return;
        }

        if (state.warningTicks > 0) {
            tickWarning(player, state);
            return;
        }

        if (state.pendingAnswerTicks > 0) {
            state.pendingAnswerTicks--;
            if (state.pendingAnswerTicks == 0) {
                whisperTell(player, "...", "dark_gray");
                state.nextForcedChase = 6000;
            }
        }

        tickStory(player, state);
        tickForcedChase(player, state);
        tickRandomWarning(player, state);
    }

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String message = event.getRawText().trim().toLowerCase(Locale.ROOT);
        if (message.equals("!nwreset") || message.equals("/nwreset")) {
            event.setCanceled(true);
            player.getPersistentData().remove("NightWhisperCaughtForever");
            states.remove(player.getUUID());
            tell(player, "reset", "green");
            return;
        }

        HorrorState state = states.get(player.getUUID());
        if (state == null || state.pendingAnswerTicks <= 0) return;
        if (message.equals("да") || message.equals("yes") || message.equals("y") || message.equals("ага") || message.equals("ok") || message.equals("ок")) {
            event.setCanceled(true);
            state.pendingAnswerTicks = 0;
            state.storyIndex = 0;
            state.storyDelay = 40;
            whisperTell(player, "then listen", "dark_gray");
        } else if (message.equals("нет") || message.equals("no") || message.equals("n") || message.equals("не") || message.equals("nope")) {
            event.setCanceled(true);
            state.pendingAnswerTicks = 0;
            whisperTell(player, "oh okay", "gray");
            state.nextForcedChase = 6000;
        }
    }


    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (isCaughtForever(player)) {
            HorrorState state = states.computeIfAbsent(player.getUUID(), id -> new HorrorState());
            state.loginKickTicks = 100;
            run(player, "title @s actionbar {\"text\":\"I warned you...\",\"color\":\"dark_red\",\"bold\":true}");
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        states.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        if (event.getEntity().getLastHurtByMob() instanceof ServerPlayer player && RANDOM.nextInt(4) == 0) {
            run(player, "execute at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 0.45 0.55 0");
            run(player, "title @s actionbar {\"text\":\"something heard that\",\"color\":\"dark_red\",\"italic\":true}");
        }
    }

    private void tickAmbient(ServerPlayer player, HorrorState state) {
        state.nextAmbient--;
        if (state.nextAmbient <= 0) {
            run(player, "execute at @s run playsound nightwhisper:scary_daisy_bell master @s ~ ~ ~ 0.72 " + pitch(0.88F, 1.04F) + " 0");
            if (RANDOM.nextInt(3) == 0) {
                run(player, "title @s actionbar {\"text\":\"...\",\"color\":\"dark_gray\",\"italic\":true}");
            }
            state.nextAmbient = 1600 + RANDOM.nextInt(5200);
        }
    }

    private void tickRandomWarning(ServerPlayer player, HorrorState state) {
        long time = player.serverLevel().getDayTime() % 24000L;
        boolean night = time >= 12500L && time <= 23500L;
        int sky = player.serverLevel().getBrightness(net.minecraft.world.level.LightLayer.SKY, player.blockPosition());
        int block = player.serverLevel().getBrightness(net.minecraft.world.level.LightLayer.BLOCK, player.blockPosition());
        boolean dark = player.getY() < 48 || sky < 6 || block < 5;

        int speed = (night || dark) ? 1 : (RANDOM.nextInt(4) == 0 ? 1 : 0);
        if (speed == 0) return;

        state.nextWarning--;
        if (state.nextWarning <= 0) {
            startWarning(player, state);
            state.nextWarning = 1800 + RANDOM.nextInt(4200);
        }
    }

    private void startWarning(ServerPlayer player, HorrorState state) {
        state.warningTicks = 200;
        state.warningYaw = player.getYRot();
        String text = RANDOM.nextBoolean() ? "Behind" : "Don't turn around";
        run(player, "effect give @s minecraft:blindness 10 0 true");
        run(player, "execute at @s run playsound minecraft:block.sculk_shrieker.shriek master @s ~ ~ ~ 0.55 0.55 0");
        run(player, "title @s times 5 55 20");
        run(player, "title @s title {\"text\":\"" + text + "\",\"color\":\"dark_red\",\"bold\":true}");
    }

    private void tickWarning(ServerPlayer player, HorrorState state) {
        if (angleDifference(player.getYRot(), state.warningYaw) > 105.0F) {
            state.warningTicks = 0;
            startReveal(player, state);
            return;
        }

        state.warningTicks--;
        if (state.warningTicks <= 0) {
            run(player, "effect clear @s minecraft:blindness");
            askQuestion(player, state);
        }
    }

    private void startReveal(ServerPlayer player, HorrorState state) {
        state.revealTicks = 60;
        run(player, "effect clear @s minecraft:blindness");
        spawnWhisper(player, true, 4.0D, "nightwhisper_reveal");
        run(player, "execute at @s run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 1.0 0.55 0");
        run(player, "title @s times 0 30 0");
        run(player, "title @s title {\"text\":\"...\",\"color\":\"black\"}");
    }

    private void tickReveal(ServerPlayer player, HorrorState state) {
        if (state.revealTicks % 10 == 0) {
            run(player, "execute anchored eyes positioned ^ ^ ^4 run particle minecraft:sculk_soul ~ ~1 ~ 0.2 0.9 0.2 0.002 12 force @s");
        }
        state.revealTicks--;
        if (state.revealTicks <= 0) {
            removeWhispers(player, "nightwhisper_reveal", 24.0D);
            startChase(player, state);
        }
    }

    private void startChase(ServerPlayer player, HorrorState state) {
        state.chaseTicks = 600;
        state.chasePulse = 0;
        run(player, "stopsound @s master nightwhisper:scary_daisy_bell");
        run(player, "stopsound @s master minecraft:entity.warden.heartbeat");
        run(player, "title @s times 0 20 8");
        run(player, "title @s title {\"text\":\"YOU SHOULDN'T HAVE TURNED AROUND\",\"color\":\"dark_red\",\"bold\":true}");
        run(player, "title @s subtitle {\"text\":\"NOW   RUN!\",\"color\":\"red\",\"bold\":true}");
        run(player, "execute at @s run playsound minecraft:entity.warden.sonic_boom master @s ~ ~ ~ 1.0 0.5 0");
        run(player, "execute at @s run playsound nightwhisper:run_for_30_seconds master @s ~ ~ ~ 0.95 1.0 0");
        run(player, "effect give @s minecraft:nausea 31 0 true");
        spawnWhisper(player, false, -16.0D, "nightwhisper_chaser");
    }

    private void tickChase(ServerPlayer player, HorrorState state) {
        state.chasePulse++;
        if (isChaserClose(player)) {
            markCaughtForever(player);
            return;
        }
        if (state.chasePulse % 10 == 0) {
            run(player, "title @s actionbar {\"text\":\"RUN\",\"color\":\"red\",\"bold\":true,\"obfuscated\":" + (state.chasePulse % 20 == 0) + "}");
            run(player, "execute at @s run particle minecraft:damage_indicator ~ ~1 ~ 1.2 0.65 1.2 0.02 18 force @s");
        }
        if (state.chasePulse % 35 == 0) {
            run(player, "execute at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 0.85 0.65 0");
            run(player, "effect give @s minecraft:darkness 2 0 true");
        }

        state.chaseTicks--;
        if (state.chaseTicks <= 0) {
            removeWhispers(player, "nightwhisper_chaser", 128.0D);
            run(player, "effect clear @s minecraft:nausea");
            run(player, "title @s actionbar {\"text\":\"\",\"color\":\"gray\"}");
        }
    }

    private void askQuestion(ServerPlayer player, HorrorState state) {
        String name = player.getScoreboardName();
        state.pendingAnswerTicks = 1200;
        whisperTell(player, "Hello " + name + " you want talk me?", "gray");
    }

    private void tickStory(ServerPlayer player, HorrorState state) {
        if (state.storyIndex < 0) return;
        state.storyDelay--;
        if (state.storyDelay > 0) return;

        String[] story = {
                "I found a strange mod on Reddit.",
                "Everyone said it was just a joke.",
                "When I opened the world, the Exit button disappeared.",
                "I tried to delete it. It copied itself back.",
                "Now I hear every player who installs it.",
                "Do not trust the quiet parts of the night."
        };

        if (state.storyIndex < story.length) {
            whisperTell(player, story[state.storyIndex], "dark_gray");
            run(player, "execute at @s run playsound minecraft:block.sculk_sensor.clicking master @s ~ ~ ~ 0.7 " + pitch(0.55F, 0.9F) + " 0");
            state.storyIndex++;
            state.storyDelay = 90;
        } else {
            state.storyIndex = -1;
            state.nextForcedChase = 6000;
            whisperTell(player, "now run when I say run", "dark_red");
        }
    }

    private void tickForcedChase(ServerPlayer player, HorrorState state) {
        if (state.nextForcedChase < 0) return;
        state.nextForcedChase--;
        if (state.nextForcedChase <= 0) {
            startChase(player, state);
            state.nextForcedChase = 6000;
        }
    }


    private WhisperEntity spawnWhisper(ServerPlayer player, boolean frozen, double distance, String tag) {
        ServerLevel level = player.serverLevel();
        WhisperEntity whisper = ModEntities.WHISPER.get().create(level, EntitySpawnReason.TRIGGERED);
        if (whisper == null) return null;

        Vec3 look = player.getLookAngle().normalize();
        Vec3 pos = player.position().add(look.scale(distance));
        whisper.moveTo(pos.x, player.getY(), pos.z, player.getYRot() + 180.0F, 0.0F);
        whisper.addTag(tag);
        whisper.setNoAi(frozen);
        whisper.setSilent(true);
        whisper.setPersistenceRequired();
        if (!frozen) {
            whisper.setTarget(player);
        }
        level.addFreshEntity(whisper);
        return whisper;
    }

    private void removeWhispers(ServerPlayer player, String tag, double radius) {
        ServerLevel level = player.serverLevel();
        for (WhisperEntity whisper : level.getEntitiesOfClass(WhisperEntity.class, player.getBoundingBox().inflate(radius), e -> e.getTags().contains(tag))) {
            whisper.discard();
        }
    }

    private boolean isChaserClose(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        for (WhisperEntity whisper : level.getEntitiesOfClass(WhisperEntity.class, player.getBoundingBox().inflate(3.2D), e -> e.getTags().contains("nightwhisper_chaser"))) {
            if (whisper.tickCount > 45 && whisper.distanceTo(player) < 2.25F) return true;
        }
        return false;
    }

    public static void markCaughtForever(ServerPlayer player) {
        player.getPersistentData().putBoolean("NightWhisperCaughtForever", true);
        kickWarned(player);
    }

    private static boolean isCaughtForever(ServerPlayer player) {
        return player.getPersistentData().getBoolean("NightWhisperCaughtForever");
    }

    private static void kickWarned(ServerPlayer player) {
        player.connection.disconnect(Component.literal("I warned you..."));
    }

    private float angleDifference(float current, float start) {
        float diff = (current - start) % 360.0F;
        if (diff < -180.0F) diff += 360.0F;
        if (diff > 180.0F) diff -= 360.0F;
        return Math.abs(diff);
    }

    private void tell(ServerPlayer player, String text, String color) {
        run(player, "tellraw @s {\"text\":\"" + escapeJson(text) + "\",\"color\":\"" + color + "\",\"italic\":true}");
    }

    private void whisperTell(ServerPlayer player, String text, String color) {
        run(player, "tellraw @s ["
                + "{\"text\":\"[\",\"color\":\"dark_gray\"},"
                + "{\"text\":\"Whisper\",\"color\":\"dark_gray\",\"obfuscated\":true},"
                + "{\"text\":\"] \",\"color\":\"dark_gray\"},"
                + "{\"text\":\"" + escapeJson(text) + "\",\"color\":\"" + color + "\",\"italic\":true}]");
    }

    private String escapeJson(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private float pitch(float min, float max) {
        return min + RANDOM.nextFloat() * (max - min);
    }

    private void run(ServerPlayer player, String command) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        CommandSourceStack source = player.createCommandSourceStack().withSuppressedOutput().withPermission(2);
        server.getCommands().performPrefixedCommand(source, command);
    }
}
