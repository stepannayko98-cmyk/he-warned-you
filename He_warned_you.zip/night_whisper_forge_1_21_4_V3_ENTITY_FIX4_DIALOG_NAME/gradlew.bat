@echo off
setlocal
set GRADLE_VERSION=8.14
set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set LOCAL_GRADLE=%GRADLE_USER_HOME%\nightwhisper-gradle\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%LOCAL_GRADLE%\bin\gradle.bat

if not exist "%GRADLE_BIN%" (
  echo Gradle %GRADLE_VERSION% not found. Downloading it now...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $version='%GRADLE_VERSION%'; $base=Join-Path $env:USERPROFILE '.gradle\nightwhisper-gradle'; $zip=Join-Path $base ('gradle-' + $version + '-bin.zip'); $url='https://services.gradle.org/distributions/gradle-' + $version + '-bin.zip'; New-Item -ItemType Directory -Force -Path $base | Out-Null; Invoke-WebRequest -Uri $url -OutFile $zip; Expand-Archive -Path $zip -DestinationPath $base -Force; Remove-Item $zip -Force"
  if errorlevel 1 (
    echo Failed to download Gradle. Check your internet connection or install Gradle manually.
    exit /b 1
  )
)

call "%GRADLE_BIN%" %*
