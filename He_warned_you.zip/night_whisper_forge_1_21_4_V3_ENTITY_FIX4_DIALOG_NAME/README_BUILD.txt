Night Whisper Forge 1.21.4

Build:
  .\gradlew.bat build

Jar:
  build\libs\nightwhisper-1.2.3.jar

Test reset:
  If you get caught and want to test again, join and quickly type !nwreset during the short warning delay.
  If you cannot type it in time, remove the mod temporarily or delete your playerdata for that test world.
